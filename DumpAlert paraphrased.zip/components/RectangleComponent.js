import React, { useMemo } from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const RectangleComponent = ({
  buttonText,
  rectangleViewTop,
  rectangleViewLeft,
  rectangleViewWidth,
  rectangleViewHeight,
  logInBackgroundColor,
  propHeight,
  propWidth,
  propTop,
  propLeft,
  onRectanglePressablePress,
}) => {
  const rectanglePressableStyle = useMemo(() => {
    return {
      ...getStyleValue("top", rectangleViewTop),
      ...getStyleValue("left", rectangleViewLeft),
      ...getStyleValue("width", rectangleViewWidth),
      ...getStyleValue("height", rectangleViewHeight),
    };
  }, [
    rectangleViewTop,
    rectangleViewLeft,
    rectangleViewWidth,
    rectangleViewHeight,
  ]);

  const rectangleView1Style = useMemo(() => {
    return {
      ...getStyleValue("backgroundColor", logInBackgroundColor),
    };
  }, [logInBackgroundColor]);

  const logInStyle = useMemo(() => {
    return {
      ...getStyleValue("height", propHeight),
      ...getStyleValue("width", propWidth),
      ...getStyleValue("top", propTop),
      ...getStyleValue("left", propLeft),
    };
  }, [propHeight, propWidth, propTop, propLeft]);

  return (
    <Pressable
      style={[styles.rectangleParent, rectanglePressableStyle]}
      onPress={onRectanglePressablePress}
    >
      <View style={[styles.componentChild, rectangleView1Style]} />
      <Text style={[styles.logIn, logInStyle]}>{buttonText}</Text>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  componentChild: {
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: Border.br_3xl,
    backgroundColor: Color.colorMaroon_200,
    position: "absolute",
  },
  logIn: {
    height: "60.47%",
    width: "73.39%",
    top: "23.26%",
    left: "12.9%",
    fontSize: FontSize.size_3xl,
    fontFamily: FontFamily.icebergRegular,
    color: Color.colorWhite,
    textAlign: "center",
    position: "absolute",
  },
  rectangleParent: {
    top: 7,
    left: 230,
    width: 124,
    height: 43,
    position: "absolute",
  },
});

export default RectangleComponent;
