import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily } from "../GlobalStyles";

const SmileyFaceForm = () => {
  const navigation = useNavigation();

  return (
    <Pressable
      style={styles.component6}
      onPress={() => navigation.navigate("Smiley")}
    >
      <View style={styles.component6Child} />
      <Text style={styles.pressHereTo}>
        Press here to receive a smiley face
      </Text>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  component6Child: {
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    backgroundColor: Color.colorBlack,
    borderStyle: "solid",
    borderColor: Color.colorGray_100,
    borderWidth: 1,
    position: "absolute",
  },
  pressHereTo: {
    height: "55.56%",
    width: "91.44%",
    top: "19.44%",
    left: "3.21%",
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.icebergRegular,
    color: Color.colorGray_100,
    textAlign: "center",
    position: "absolute",
  },
  component6: {
    top: 25,
    left: 166,
    width: 187,
    height: 36,
    position: "absolute",
  },
});

export default SmileyFaceForm;
