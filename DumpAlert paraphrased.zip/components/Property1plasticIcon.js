import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, ImageSourcePropType } from "react-native";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1plasticIcon = ({
  imageDimensions,
  propTop,
  propLeft,
  propHeight,
  propOverflow,
}) => {
  const property1plasticIconStyle = useMemo(() => {
    return {
      ...getStyleValue("top", propTop),
      ...getStyleValue("left", propLeft),
      ...getStyleValue("height", propHeight),
      ...getStyleValue("overflow", propOverflow),
    };
  }, [propTop, propLeft, propHeight, propOverflow]);

  return (
    <Image
      style={[styles.property1plasticIcon, property1plasticIconStyle]}
      contentFit="cover"
      source={imageDimensions}
    />
  );
};

const styles = StyleSheet.create({
  property1plasticIcon: {
    position: "absolute",
    top: 370,
    left: 20,
    width: 183,
    height: 320,
  },
});

export default Property1plasticIcon;
