import React, { useMemo } from "react";
import { StyleSheet, View, Text } from "react-native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1OnClick = ({
  propTop,
  propLeft,
  propBackgroundColor,
  propColor,
}) => {
  const property1OnClickStyle = useMemo(() => {
    return {
      ...getStyleValue("top", propTop),
      ...getStyleValue("left", propLeft),
    };
  }, [propTop, propLeft]);

  const rectangleViewStyle = useMemo(() => {
    return {
      ...getStyleValue("backgroundColor", propBackgroundColor),
    };
  }, [propBackgroundColor]);

  const accessStyle = useMemo(() => {
    return {
      ...getStyleValue("color", propColor),
    };
  }, [propColor]);

  return (
    <View style={[styles.property1onclick, property1OnClickStyle]}>
      <View style={[styles.property1onclickChild, rectangleViewStyle]} />
      <Text style={[styles.access, accessStyle]}>Access</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  property1onclickChild: {
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: Border.br_34xl,
    backgroundColor: Color.colorDarkgoldenrod,
    position: "absolute",
  },
  access: {
    height: "45.63%",
    width: "72.08%",
    top: "27.18%",
    left: "14.94%",
    fontSize: FontSize.size_25xl,
    fontFamily: FontFamily.icebergRegular,
    color: Color.colorBlack,
    textAlign: "center",
    position: "absolute",
  },
  property1onclick: {
    top: 266,
    left: 20,
    width: 308,
    height: 103,
    position: "absolute",
  },
});

export default Property1OnClick;
