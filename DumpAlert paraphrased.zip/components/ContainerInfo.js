import React, { useMemo } from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const ContainerInfo = ({ componentText, propLeft, onComponent1Press }) => {
  const component1Style = useMemo(() => {
    return {
      ...getStyleValue("left", propLeft),
    };
  }, [propLeft]);

  return (
    <Pressable
      style={[styles.component1, component1Style]}
      onPress={onComponent1Press}
    >
      <View style={styles.component1Child} />
      <Text style={styles.info}>{componentText}</Text>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  component1Child: {
    height: "100%",
    width: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: Border.br_6xl,
    backgroundColor: Color.colorSeagreen_100,
    position: "absolute",
  },
  info: {
    height: "43.86%",
    width: "63.5%",
    top: "33.33%",
    left: "18.98%",
    fontSize: FontSize.size_3xl,
    fontFamily: FontFamily.icebergRegular,
    color: Color.colorBlack,
    textAlign: "center",
    position: "absolute",
  },
  component1: {
    top: 343,
    left: 200,
    width: 137,
    height: 57,
    position: "absolute",
  },
});

export default ContainerInfo;
