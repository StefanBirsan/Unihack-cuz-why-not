import * as React from "react";
import { StyleSheet, View } from "react-native";
import Property1OnClick from "./Property1OnClick";
import { Border, Color } from "../GlobalStyles";

const Component5 = () => {
  return (
    <View style={styles.component5}>
      <Property1OnClick
        propTop={20}
        propLeft={20}
        propBackgroundColor="rgba(217, 217, 217, 0.07)"
        propColor="rgba(0, 0, 0, 0.1)"
      />
      <Property1OnClick
        propTop={143}
        propLeft={20}
        propBackgroundColor="rgba(112, 59, 10, 0.6)"
        propColor="rgba(0, 0, 0, 0.8)"
      />
      <Property1OnClick />
    </View>
  );
};

const styles = StyleSheet.create({
  component5: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 348,
    height: 389,
    overflow: "hidden",
  },
});

export default Component5;
