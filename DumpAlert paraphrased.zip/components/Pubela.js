import * as React from "react";
import { StyleSheet, View } from "react-native";
import Property1plasticIcon from "./Property1plasticIcon";
import { Border, Color } from "../GlobalStyles";

const Pubela = () => {
  return (
    <View style={styles.pubela}>
      <Property1plasticIcon
        imageDimensions={require("../assets/property-1deseuri.png")}
        propTop={20}
        propLeft={20}
        propHeight={320}
        propOverflow="unset"
      />
      <Property1plasticIcon
        imageDimensions={require("../assets/property-1plastic.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  pubela: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 223,
    height: 709,
    overflow: "hidden",
  },
});

export default Pubela;
