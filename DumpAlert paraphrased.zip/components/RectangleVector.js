import * as React from "react";
import { StyleSheet, View } from "react-native";

const RectangleVector = () => {
  return <View style={styles.rectangleView} />;
};

const styles = StyleSheet.create({
  rectangleView: {
    width: 360,
    height: 54,
  },
});

export default RectangleVector;
