/* fonts */
export const FontFamily = {
  icebergRegular: "Iceberg-Regular",
  timesNewRoman: "Times New Roman",
  kumarOneRegular: "KumarOne-Regular",
};
/* font sizes */
export const FontSize = {
  size_25xl: 44,
  size_7xl: 26,
  size_3xl: 22,
  size_xl: 20,
  size_xs: 12,
  size_13xl: 32,
};
/* Colors */
export const Color = {
  colorGray_100: "#2b2b2b",
  colorGray_200: "rgba(22, 14, 14, 0.7)",
  colorGray_300: "rgba(0, 0, 0, 0.1)",
  colorGainsboro_100: "#d9d9d9",
  colorGainsboro_200: "rgba(217, 217, 217, 0.07)",
  colorBlack: "#000",
  colorBlueviolet: "#9747ff",
  colorWhite: "#fff",
  colorDarkslategray: "#373131",
  colorDarkgoldenrod: "rgba(198, 123, 9, 0.8)",
  colorMaroon_100: "#7c0707",
  colorMaroon_200: "rgba(124, 7, 7, 0.7)",
  colorDarkslateblue_100: "#5b446a",
  colorDarkslateblue_200: "rgba(91, 68, 106, 0.69)",
  colorSeagreen_100: "rgba(60, 123, 68, 0.7)",
  colorSeagreen_200: "rgba(7, 124, 61, 0.7)",
};
/* border radiuses */
export const Border = {
  br_34xl: 53,
  br_8xs: 5,
  br_3xl: 22,
  br_xs: 12,
  br_112xl: 131,
  br_6xl: 25,
};
