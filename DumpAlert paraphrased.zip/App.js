const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import LoadPage from "./screens/LoadPage";
import SearchTruck from "./screens/SearchTruck";
import Pubela from "./components/Pubela";
import Garbage from "./screens/Garbage";
import Map1 from "./screens/Map1";
import Smiley from "./screens/Smiley";
import Reminders from "./screens/Reminders";
import Component5 from "./components/Component5";
import Map2 from "./screens/Map2";
import PrivacyPolicy from "./screens/PrivacyPolicy";
import TOS from "./screens/TOS";
import PersonalInfo from "./screens/PersonalInfo";
import MainScreen from "./screens/MainScreen";
import Info from "./screens/Info";
import FAQ from "./screens/FAQ";
import LogIn from "./screens/LogIn";
import SignUp from "./screens/SignUp";
import RectangleVector from "./components/RectangleVector";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  const [fontsLoaded, error] = useFonts({
    "Iceberg-Regular": require("./assets/fonts/Iceberg-Regular.ttf"),
    "KumarOne-Regular": require("./assets/fonts/KumarOne-Regular.ttf"),
  });

  if (!fontsLoaded && !error) {
    return null;
  }

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="LoadPage"
              component={LoadPage}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SearchTruck"
              component={SearchTruck}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Garbage"
              component={Garbage}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Map1"
              component={Map1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Smiley"
              component={Smiley}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Reminders"
              component={Reminders}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Map2"
              component={Map2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="PrivacyPolicy"
              component={PrivacyPolicy}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="TOS"
              component={TOS}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="PersonalInfo"
              component={PersonalInfo}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="MainScreen"
              component={MainScreen}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Info"
              component={Info}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="FAQ"
              component={FAQ}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="LogIn"
              component={LogIn}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SignUp"
              component={SignUp}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
