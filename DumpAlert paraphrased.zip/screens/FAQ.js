import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import RectangleComponent from "../components/RectangleComponent";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const FAQ = () => {
  const navigation = useNavigation();

  return (
    <LinearGradient
      style={styles.faq}
      locations={[0, 1]}
      colors={["#414141", "#3c7b44"]}
    >
      <View style={styles.faqInner}>
        <View style={[styles.frameWrapper, styles.frameLayout]}>
          <View style={[styles.frameContainer, styles.faqChildPosition]}>
            <View style={[styles.frameContainer, styles.faqChildPosition]}>
              <Text
                style={[styles.q1WhatIs, styles.frameLayout]}
              >{`Q1: What is the purpose of the garbage truck tracker app?
A: The garbage truck tracker app is designed to provide real-time tracking and management of garbage collection trucks. It allows users to monitor the location and status of garbage trucks, schedule pickups, and receive notifications for optimized waste management.
Q2: How can I track the location of my garbage truck?
A: To track your garbage truck, simply log in to the app and access the tracking feature. You'll be able to see the real-time location of the assigned garbage truck on the map.
Q3: Can I schedule a garbage pickup using the app?
A: Yes, the app allows you to schedule garbage pickups at your convenience. Navigate to the scheduling feature, choose a suitable time, and confirm your pickup request. You'll receive notifications to keep you informed about the status of your scheduled pickup.
Q4: What information is available about each garbage truck on the app?
A: The app provides detailed information about each garbage truck, including its current location, status (e.g., en route, at pickup location, completed), and historical pickup data.
Q5: How does the app optimize waste collection routes?
A: The garbage truck tracker app uses advanced algorithms to optimize waste collection routes. This helps reduce fuel consumption, minimize environmental impact, and improve overall efficiency by ensuring trucks follow the most time-efficient routes.
Q6: Is the app available for both residential and commercial use?
A: Yes, the app is designed to cater to both residential and commercial users. Whether you're a homeowner or a business owner, you can benefit from the features of the garbage truck tracker app to manage waste pickups efficiently.
Q7: Can I receive notifications about upcoming garbage pickups?
A: Absolutely. The app provides push notifications to keep you informed about upcoming garbage pickups, as well as status updates such as when the truck is on its way or when the pickup is completed.
Q8: How do I report issues or provide feedback about the service?
A: We encourage users to report any issues or provide feedback through the app's customer support feature. You can also reach out to our customer support team directly via email or phone for prompt assistance.
Q9: Is my personal information secure on the app?
A: Yes, we take the security and privacy of user information seriously. The app employs encryption protocols and follows best practices to ensure the protection of your personal data.
Q10: Can I use the app on multiple devices?
A: Yes, the app is designed to be accessible from multiple devices. Simply log in with your account credentials on any supported device to access the garbage truck tracking features.
`}</Text>
            </View>
          </View>
        </View>
      </View>
      <Image
        style={[styles.faqChild, styles.faqChildPosition]}
        contentFit="cover"
        source={require("../assets/rectangle-15.png")}
      />
      <RectangleComponent
        buttonText="Back"
        rectangleViewTop={9}
        rectangleViewLeft={259}
        rectangleViewWidth={101}
        rectangleViewHeight={35}
        logInBackgroundColor="rgba(124, 7, 7, 0.7)"
        propHeight="60.57%"
        propWidth="73.37%"
        propTop="23.14%"
        propLeft="12.87%"
        onRectanglePressablePress={() => navigation.navigate("LoadPage")}
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  frameLayout: {
    height: 644,
    width: 333,
  },
  faqChildPosition: {
    top: 0,
    left: 0,
    position: "absolute",
  },
  q1WhatIs: {
    top: 20,
    left: 3,
    fontSize: FontSize.size_3xl,
    fontFamily: FontFamily.icebergRegular,
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
    height: 644,
  },
  frameContainer: {
    height: 644,
    width: 333,
  },
  frameWrapper: {
    top: 7,
    left: 0,
    height: 644,
    position: "absolute",
  },
  faqInner: {
    top: 28,
    left: 14,
    height: 651,
    width: 333,
    position: "absolute",
  },
  faqChild: {
    width: 360,
    height: 54,
  },
  faq: {
    flex: 1,
    width: "100%",
    height: 800,
    backgroundColor: "transparent",
  },
});

export default FAQ;
