import * as React from "react";
import { Text, StyleSheet, View, ImageBackground } from "react-native";
import { useNavigation } from "@react-navigation/native";
import RectangleComponent from "../components/RectangleComponent";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const LogIn = () => {
  const navigation = useNavigation();

  return (
    <ImageBackground
      style={styles.logInIcon}
      resizeMode="cover"
      source={require("../assets/login.png")}
    >
      <Text style={styles.dontHaveAn}>Don’t have an account yet?</Text>
      <View style={styles.logInChild} />
      <Text style={[styles.enterYourPassword, styles.enterTypo]}>
        Enter your password:
      </Text>
      <Text style={[styles.enterYourEmail, styles.enterTypo]}>
        Enter your email adress:
      </Text>
      <View style={[styles.logInItem, styles.logLayout]} />
      <View style={[styles.logInInner, styles.logLayout]} />
      <RectangleComponent
        buttonText="Log in"
        rectangleViewTop={340}
        rectangleViewLeft={118}
        rectangleViewWidth={124}
        rectangleViewHeight={43}
        logInBackgroundColor="rgba(7, 124, 61, 0.7)"
        propHeight="60.47%"
        propWidth="73.39%"
        propTop="23.26%"
        propLeft="12.9%"
        onRectanglePressablePress={() => navigation.navigate("MainScreen")}
      />
      <RectangleComponent
        buttonText="Sign up"
        rectangleViewTop={638}
        rectangleViewLeft={118}
        rectangleViewWidth={124}
        rectangleViewHeight={43}
        logInBackgroundColor="rgba(124, 7, 7, 0.7)"
        propHeight="60.47%"
        propWidth="73.39%"
        propTop="23.26%"
        propLeft="12.9%"
        onRectanglePressablePress={() => navigation.navigate("SignUp")}
      />
      <RectangleComponent
        buttonText="Back"
        rectangleViewTop={753}
        rectangleViewLeft={250}
        rectangleViewWidth={101}
        rectangleViewHeight={35}
        logInBackgroundColor="rgba(124, 7, 7, 0.7)"
        propHeight="60.57%"
        propWidth="73.37%"
        propTop="23.14%"
        propLeft="12.87%"
        onRectanglePressablePress={() => navigation.navigate("LoadPage")}
      />
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  enterTypo: {
    height: 26,
    width: 263,
    textAlign: "left",
    left: 48,
    color: Color.colorBlack,
    fontFamily: FontFamily.icebergRegular,
    fontSize: FontSize.size_3xl,
    position: "absolute",
  },
  logLayout: {
    height: 57,
    width: 301,
    backgroundColor: Color.colorGainsboro_100,
    borderRadius: Border.br_112xl,
    left: 29,
    position: "absolute",
  },
  dontHaveAn: {
    top: 562,
    left: 60,
    textAlign: "center",
    width: 241,
    height: 65,
    color: Color.colorBlack,
    fontFamily: FontFamily.icebergRegular,
    fontSize: FontSize.size_3xl,
    position: "absolute",
  },
  logInChild: {
    top: 746,
    left: 0,
    backgroundColor: Color.colorDarkslateblue_200,
    width: 360,
    height: 54,
    position: "absolute",
  },
  enterYourPassword: {
    top: 222,
  },
  enterYourEmail: {
    top: 104,
  },
  logInItem: {
    top: 130,
  },
  logInInner: {
    top: 248,
  },
  logInIcon: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default LogIn;
