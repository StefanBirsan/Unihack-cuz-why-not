import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import RectangleComponent from "../components/RectangleComponent";

const Smiley = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.smiley}>
      <Image
        style={styles.smileyChild}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Image
        style={[styles.smileyItem, styles.smileyLayout]}
        contentFit="cover"
        source={require("../assets/star-1.png")}
      />
      <Image
        style={[styles.smileyInner, styles.smileyLayout]}
        contentFit="cover"
        source={require("../assets/star-1.png")}
      />
      <Image
        style={styles.ellipseIcon}
        contentFit="cover"
        source={require("../assets/ellipse-4.png")}
      />
      <RectangleComponent
        buttonText="Back"
        rectangleViewTop={747}
        rectangleViewLeft={247}
        rectangleViewWidth={101}
        rectangleViewHeight={35}
        logInBackgroundColor="#9bbea4"
        propHeight="60.57%"
        propWidth="73.37%"
        propTop="23.14%"
        propLeft="12.87%"
        onRectanglePressablePress={() => navigation.navigate("MainScreen")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  smileyLayout: {
    height: 35,
    width: 41,
    top: 335,
    position: "absolute",
  },
  smileyChild: {
    top: 291,
    left: 89,
    width: 183,
    height: 171,
    position: "absolute",
  },
  smileyItem: {
    left: 127,
  },
  smileyInner: {
    left: 192,
  },
  ellipseIcon: {
    top: 402,
    left: 136,
    width: 90,
    height: 24,
    position: "absolute",
  },
  smiley: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default Smiley;
