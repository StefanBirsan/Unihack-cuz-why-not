import * as React from "react";
import { StyleSheet, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import Property1plasticIcon from "../components/Property1plasticIcon";
import { Color } from "../GlobalStyles";

const Garbage = () => {
  return (
    <LinearGradient
      style={styles.garbage}
      locations={[0, 0.31, 0.78, 1]}
      colors={["#3c7b44", "#92b89b", "#000", "#06ef42"]}
    >
      <View style={styles.garbageChild} />
      <Property1plasticIcon
        imageDimensions={require("../assets/pubela.png")}
        propTop={60}
        propLeft={89}
        propHeight={319}
        propOverflow="hidden"
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  garbageChild: {
    position: "absolute",
    top: 746,
    left: 0,
    backgroundColor: Color.colorGray_200,
    width: 360,
    height: 54,
  },
  garbage: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    backgroundColor: "transparent",
  },
});

export default Garbage;
