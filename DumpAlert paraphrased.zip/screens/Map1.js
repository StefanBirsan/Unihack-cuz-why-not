import * as React from "react";
import { ImageBackground, StyleSheet } from "react-native";

const Map1 = () => {
  return (
    <ImageBackground
      style={styles.mapIcon}
      resizeMode="cover"
      source={require("../assets/map.png")}
    />
  );
};

const styles = StyleSheet.create({
  mapIcon: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default Map1;
