import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import RectangleComponent from "../components/RectangleComponent";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const PrivacyPolicy = () => {
  const navigation = useNavigation();

  return (
    <LinearGradient
      style={styles.privacyPolicy}
      locations={[0, 1]}
      colors={["#414141", "#3c7b44"]}
    >
      <View style={[styles.privacyPolicyInner, styles.frameWrapperLayout]}>
        <View style={[styles.frameWrapper, styles.frameWrapperPosition]}>
          <View style={[styles.frameWrapper, styles.frameWrapperPosition]}>
            <Text
              style={styles.privacyPolicyFor}
            >{`Privacy Policy for Dump Alert

Last Updated: 18/11/2023

1. Introduction

Thank you for choosing Dump Alert ("we," "us," or "our"). This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application (the "App"). Please read this Privacy Policy carefully. By using the App, you agree to the terms of this Privacy Policy.

2. Information We Collect

a. Information You Provide: We may collect information that you voluntarily provide when using the App, such as your name, email address, phone number, and address.

b. Automatically Collected Information: We may automatically collect certain information when you use the App, including your device information, IP address, and usage patterns.

3. Use of Your Information

a. Provide and Maintain the App: We use the information we collect to provide, personalize, and improve the App, as well as to respond to your inquiries.

b. Communications: We may use your email address to send you updates, newsletters, or information about our services. You can opt-out of receiving these communications.

4. Sharing Your Information

a. Service Providers: We may share your information with third-party service providers that help us operate the App and provide services.

b. Legal Compliance: We may disclose your information to comply with applicable laws, regulations, or legal requests.

5. Your Choices

a. Opt-Out: You can opt-out of receiving promotional emails by following the instructions provided in the email.

b. Access and Update: You can access and update your personal information by contacting us at contact@hungrydevs.com.

6. Security

We take reasonable measures to protect your information from unauthorized access, disclosure, alteration, and destruction. However, no method of transmission over the internet or electronic storage is 100% secure.

7. Children's Privacy

The App is not intended for individuals under the age of 18. We do not knowingly collect personal information from children. If you believe that we have inadvertently collected information from a child, please contact us at contact@hungrydevs.com.

8. Changes to this Privacy Policy

We may update this Privacy Policy to reflect changes in our data practices. The date of the latest revision will be indicated at the top of this Privacy Policy.

9. Contact Information

If you have any questions about this Privacy Policy, please contact us at contact@hungrydevs.com.`}</Text>
          </View>
        </View>
      </View>
      <View style={[styles.privacyPolicyChild, styles.frameWrapperPosition]} />
      <RectangleComponent
        buttonText="Back"
        rectangleViewTop={9}
        rectangleViewLeft={253}
        rectangleViewWidth={101}
        rectangleViewHeight={35}
        logInBackgroundColor="rgba(124, 7, 7, 0.7)"
        propHeight="60.57%"
        propWidth="73.37%"
        propTop="23.14%"
        propLeft="12.87%"
        onRectanglePressablePress={() => navigation.navigate("TOS")}
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  frameWrapperLayout: {
    height: 494,
    width: 298,
  },
  frameWrapperPosition: {
    left: 0,
    top: 0,
    position: "absolute",
  },
  privacyPolicyFor: {
    left: -6,
    fontSize: FontSize.size_3xl,
    fontFamily: FontFamily.timesNewRoman,
    color: Color.colorWhite,
    textAlign: "left",
    top: 0,
    height: 494,
    width: 298,
    position: "absolute",
  },
  frameWrapper: {
    height: 494,
    width: 298,
  },
  privacyPolicyInner: {
    top: 56,
    left: 31,
    position: "absolute",
    width: 298,
  },
  privacyPolicyChild: {
    backgroundColor: Color.colorDarkslateblue_100,
    width: 360,
    height: 54,
  },
  privacyPolicy: {
    flex: 1,
    width: "100%",
    height: 800,
    backgroundColor: "transparent",
  },
});

export default PrivacyPolicy;
