import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import RectangleComponent from "../components/RectangleComponent";
import SmileyFaceForm from "../components/SmileyFaceForm";
import { Color, FontFamily, FontSize } from "../GlobalStyles";

const MainScreen = () => {
  const navigation = useNavigation();

  return (
    <LinearGradient
      style={styles.mainScreen}
      locations={[0.09, 0.65, 1]}
      colors={["#000", "#9bbea4", "#3c7b44"]}
    >
      <View style={styles.mainScreenChild} />
      <RectangleComponent
        buttonText="Log Out"
        rectangleViewTop={757}
        rectangleViewLeft={252}
        rectangleViewWidth={101}
        rectangleViewHeight={35}
        logInBackgroundColor="#7c0707"
        propHeight="60.57%"
        propWidth="73.37%"
        propTop="23.14%"
        propLeft="12.87%"
        onRectanglePressablePress={() => navigation.navigate("LoadPage")}
      />
      <Text style={[styles.swipeRightTo, styles.swipeTypo]}>
        Swipe right to search for the closest garbage truck
      </Text>
      <Image
        style={[styles.mainScreenItem, styles.mainLayout]}
        contentFit="cover"
        source={require("../assets/arrow-1.png")}
      />
      <Image
        style={[styles.mainScreenInner, styles.mainLayout]}
        contentFit="cover"
        source={require("../assets/arrow-2.png")}
      />
      <Text style={[styles.swipeLeftFor, styles.swipeTypo]}>
        Swipe left for your reminders
      </Text>
      <SmileyFaceForm />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  swipeTypo: {
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.icebergRegular,
    fontSize: FontSize.size_7xl,
    position: "absolute",
  },
  mainLayout: {
    height: 15,
    width: 277,
    position: "absolute",
  },
  mainScreenChild: {
    top: 746,
    left: 0,
    backgroundColor: Color.colorGray_200,
    width: 360,
    height: 54,
    position: "absolute",
  },
  swipeRightTo: {
    top: 260,
    left: 34,
    width: 281,
    height: 95,
  },
  mainScreenItem: {
    top: 332,
    left: 37,
  },
  mainScreenInner: {
    top: 463,
    left: 36,
  },
  swipeLeftFor: {
    top: 391,
    left: 55,
    width: 280,
    height: 47,
  },
  mainScreen: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    backgroundColor: "transparent",
  },
});

export default MainScreen;
