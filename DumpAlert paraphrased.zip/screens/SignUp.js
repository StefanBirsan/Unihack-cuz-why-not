import * as React from "react";
import { StyleSheet, View, Text, ImageBackground } from "react-native";
import { useNavigation } from "@react-navigation/native";
import RectangleComponent from "../components/RectangleComponent";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const SignUp = () => {
  const navigation = useNavigation();

  return (
    <ImageBackground
      style={styles.signUpIcon}
      resizeMode="cover"
      source={require("../assets/signup.png")}
    >
      <RectangleComponent
        buttonText="Back"
        rectangleViewTop={752}
        rectangleViewLeft={247}
        rectangleViewWidth={101}
        rectangleViewHeight={35}
        logInBackgroundColor="rgba(124, 7, 7, 0.7)"
        propHeight="60.57%"
        propWidth="73.37%"
        propTop="23.14%"
        propLeft="12.87%"
        onRectanglePressablePress={() => navigation.navigate("LoadPage")}
      />
      <RectangleComponent
        buttonText="Log in"
        rectangleViewTop={426}
        rectangleViewLeft={118}
        rectangleViewWidth={124}
        rectangleViewHeight={43}
        logInBackgroundColor="rgba(7, 124, 61, 0.7)"
        propHeight="60.47%"
        propWidth="73.39%"
        propTop="23.26%"
        propLeft="12.9%"
        onRectanglePressablePress={() => navigation.navigate("PersonalInfo")}
      />
      <View style={styles.signUpChild} />
      <View style={[styles.signUpItem, styles.signLayout]} />
      <View style={[styles.signUpInner, styles.signLayout]} />
      <View style={[styles.rectangleView, styles.signLayout]} />
      <Text style={[styles.enterYourEmail, styles.enterTypo]}>
        Enter your email adress:
      </Text>
      <Text style={[styles.enterYourPassword, styles.enterTypo]}>
        Enter your password:
      </Text>
      <Text style={[styles.reEnterYourpassword, styles.enterTypo]}>
        Re-enter yourpassword:
      </Text>
      <RectangleComponent
        buttonText="Back"
        rectangleViewTop={752}
        rectangleViewLeft={247}
        rectangleViewWidth={101}
        rectangleViewHeight={35}
        logInBackgroundColor="rgba(124, 7, 7, 0.7)"
        propHeight="60.57%"
        propWidth="73.37%"
        propTop="23.14%"
        propLeft="12.87%"
      />
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  signLayout: {
    height: 57,
    width: 301,
    backgroundColor: Color.colorGainsboro_100,
    borderRadius: Border.br_112xl,
    left: 30,
    position: "absolute",
  },
  enterTypo: {
    height: 26,
    width: 263,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.icebergRegular,
    fontSize: FontSize.size_3xl,
    position: "absolute",
  },
  signUpChild: {
    top: 746,
    left: 0,
    backgroundColor: Color.colorDarkslateblue_200,
    width: 360,
    height: 54,
    position: "absolute",
  },
  signUpItem: {
    top: 124,
  },
  signUpInner: {
    top: 231,
  },
  rectangleView: {
    top: 338,
  },
  enterYourEmail: {
    top: 98,
    left: 49,
    height: 26,
    width: 263,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.icebergRegular,
    fontSize: FontSize.size_3xl,
  },
  enterYourPassword: {
    top: 205,
    left: 49,
    height: 26,
    width: 263,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.icebergRegular,
    fontSize: FontSize.size_3xl,
  },
  reEnterYourpassword: {
    top: 312,
    left: 45,
  },
  signUpIcon: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default SignUp;
