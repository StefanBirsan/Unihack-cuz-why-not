import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const Reminders = () => {
  return (
    <LinearGradient
      style={styles.reminders}
      locations={[0, 0.46, 1]}
      colors={["#000", "#0e3b14", "#3c7b44"]}
    >
      <View style={styles.remindersChild} />
      <Text style={styles.yourReminders}>{`Your Reminders
`}</Text>
      <View style={[styles.remindersItem, styles.remindersLayout]} />
      <View style={[styles.remindersInner, styles.remindersLayout]} />
      <View style={[styles.rectangleView, styles.remindersLayout]} />
      <Text style={[styles.sampleReminder, styles.sampleTypo]}>
        Sample Reminder
      </Text>
      <Text style={[styles.sampleReminder1, styles.sampleTypo]}>
        Sample Reminder
      </Text>
      <Text style={[styles.sampleReminder2, styles.sampleTypo]}>
        Sample Reminder
      </Text>
      <Text style={[styles.text, styles.textTypo1]}>09:34</Text>
      <Text style={[styles.text1, styles.textTypo]}>19/11</Text>
      <Text style={[styles.text2, styles.textTypo1]}>13:00</Text>
      <Text style={[styles.text3, styles.textTypo]}>19/11</Text>
      <Text style={[styles.text4, styles.textTypo1]}>19:48</Text>
      <Text style={[styles.text5, styles.textTypo]}>19/11</Text>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  remindersLayout: {
    height: 64,
    width: 279,
    backgroundColor: Color.colorDarkslategray,
    borderRadius: Border.br_xs,
    left: 35,
    position: "absolute",
  },
  sampleTypo: {
    height: 24,
    width: 119,
    fontSize: FontSize.size_xl,
    left: 32,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.icebergRegular,
    position: "absolute",
  },
  textTypo1: {
    height: 23,
    width: 84,
    left: 211,
    fontSize: FontSize.size_xl,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.icebergRegular,
    position: "absolute",
  },
  textTypo: {
    height: 18,
    width: 103,
    left: 202,
    fontSize: FontSize.size_xl,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.icebergRegular,
    position: "absolute",
  },
  remindersChild: {
    top: 746,
    left: 0,
    backgroundColor: Color.colorGray_200,
    width: 360,
    height: 54,
    position: "absolute",
  },
  yourReminders: {
    top: 25,
    left: 75,
    fontSize: 25,
    width: 211,
    height: 32,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.icebergRegular,
    position: "absolute",
  },
  remindersItem: {
    top: 90,
  },
  remindersInner: {
    top: 179,
  },
  rectangleView: {
    top: 265,
  },
  sampleReminder: {
    top: 98,
  },
  sampleReminder1: {
    top: 187,
  },
  sampleReminder2: {
    top: 273,
  },
  text: {
    top: 100,
  },
  text1: {
    top: 123,
  },
  text2: {
    top: 189,
  },
  text3: {
    top: 212,
  },
  text4: {
    top: 274,
  },
  text5: {
    top: 298,
  },
  reminders: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    backgroundColor: "transparent",
  },
});

export default Reminders;
