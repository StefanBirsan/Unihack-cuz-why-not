import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import RectangleComponent from "../components/RectangleComponent";
import { Color, FontSize, FontFamily } from "../GlobalStyles";

const Info = () => {
  const navigation = useNavigation();

  return (
    <LinearGradient
      style={styles.info}
      locations={[0, 0.82]}
      colors={["#414141", "#3c7b44"]}
    >
      <View style={[styles.infoChild, styles.infoChildPosition]} />
      <Text style={[styles.youCanContactContainer, styles.infoChildPosition]}>
        <Text style={styles.youCanContact}>{`You can contact us at:
`}</Text>
        <Text style={styles.contacthungrydevscom}>{`contact@hungrydevs.com
`}</Text>
        <Text style={styles.youCanContact}>{` for more information.



Our Costumer Center is 24/7 and there to help you with any trouble you may encounter :
 `}</Text>
        <Text style={styles.contacthungrydevscom}>+40 770 118 618</Text>
      </Text>
      <RectangleComponent
        buttonText="Back"
        rectangleViewTop={9}
        rectangleViewLeft={251}
        rectangleViewWidth={101}
        rectangleViewHeight={35}
        logInBackgroundColor="rgba(124, 7, 7, 0.7)"
        propHeight="60.57%"
        propWidth="73.37%"
        propTop="23.14%"
        propLeft="12.87%"
        onRectanglePressablePress={() => navigation.navigate("LoadPage")}
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  infoChildPosition: {
    left: 0,
    position: "absolute",
  },
  infoChild: {
    top: 0,
    backgroundColor: Color.colorDarkslateblue_100,
    width: 360,
    height: 54,
  },
  youCanContact: {
    fontSize: FontSize.size_3xl,
  },
  contacthungrydevscom: {
    fontSize: FontSize.size_13xl,
  },
  youCanContactContainer: {
    top: 121,
    fontFamily: FontFamily.icebergRegular,
    color: Color.colorWhite,
    textAlign: "center",
    width: 352,
    height: 418,
  },
  info: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    backgroundColor: "transparent",
  },
});

export default Info;
