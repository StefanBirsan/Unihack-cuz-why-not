import * as React from "react";
import {
  StyleSheet,
  View,
  Text,
  Pressable,
  ImageBackground,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import RectangleComponent from "../components/RectangleComponent";
import ContainerInfo from "../components/ContainerInfo";
import { FontFamily, FontSize, Color } from "../GlobalStyles";

const LoadPage = () => {
  const navigation = useNavigation();

  return (
    <ImageBackground
      style={styles.loadPageIcon}
      resizeMode="cover"
      source={require("../assets/loadpage.png")}
    >
      <RectangleComponent
        buttonText="Log in"
        onRectanglePressablePress={() => navigation.navigate("LogIn")}
      />
      <View style={styles.loadPageChild} />
      <Pressable
        style={styles.termsOfServiceContainer}
        onPress={() => navigation.navigate("TOS")}
      >
        <Text style={[styles.termsOfService, styles.termsOfServiceTypo]}>
          Terms of Service
        </Text>
      </Pressable>
      <Text style={[styles.yourMusicTaste, styles.termsOfServiceTypo]}>
        Your music taste
      </Text>
      <Image
        style={styles.bullshit1Icon}
        contentFit="cover"
        source={require("../assets/bullshit-1.png")}
      />
      <Text style={styles.dumpAlert}>Dump Alert</Text>
      <ContainerInfo
        componentText={`Info
`}
        onComponent1Press={() => navigation.navigate("Info")}
      />
      <ContainerInfo
        componentText="FAQ"
        propLeft={21}
        onComponent1Press={() => navigation.navigate("FAQ")}
      />
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  termsOfServiceTypo: {
    fontFamily: FontFamily.icebergRegular,
    textAlign: "center",
  },
  loadPageChild: {
    top: 730,
    left: 68,
    borderRadius: 37,
    backgroundColor: "rgba(60, 123, 68, 0.38)",
    width: 228,
    height: 38,
    position: "absolute",
  },
  termsOfService: {
    fontSize: FontSize.size_3xl,
    lineHeight: 18,
    color: "rgba(0, 0, 0, 0.54)",
    width: 183,
    height: 21,
    textAlign: "center",
  },
  termsOfServiceContainer: {
    left: 87,
    top: 741,
    position: "absolute",
  },
  yourMusicTaste: {
    top: 575,
    left: 333,
    fontSize: 5,
    lineHeight: 4,
    color: Color.colorWhite,
    width: 25,
    height: 15,
    textAlign: "center",
    position: "absolute",
  },
  bullshit1Icon: {
    top: 371,
    left: 21,
    width: 350,
    height: 350,
    position: "absolute",
  },
  dumpAlert: {
    top: 59,
    left: 16,
    fontSize: FontSize.size_25xl,
    fontFamily: FontFamily.kumarOneRegular,
    color: "#3c7b44",
    width: 317,
    height: 127,
    textAlign: "center",
    position: "absolute",
  },
  loadPageIcon: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default LoadPage;
