import * as React from "react";
import {
  StyleSheet,
  View,
  Text,
  Pressable,
  ImageBackground,
} from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import RectangleComponent from "../components/RectangleComponent";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const PersonalInfo = () => {
  const navigation = useNavigation();

  return (
    <LinearGradient
      style={styles.personalInfo}
      locations={[0, 0.5, 1]}
      colors={["#6bec69", "#0c8909", "#05fe00"]}
    >
      <ImageBackground
        style={[styles.icon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/personalinfo.png")}
      >
        <View style={styles.personalInfoChild} />
        <View style={[styles.personalInfoItem, styles.personalLayout]} />
        <View style={[styles.personalInfoInner, styles.personalLayout]} />
        <View style={[styles.rectangleView, styles.personalLayout]} />
        <View style={[styles.personalInfoChild1, styles.personalLayout]} />
        <Text style={[styles.firstAndLast, styles.addressTypo]}>
          First and Last Name:
        </Text>
        <Text style={[styles.address, styles.addressTypo]}>Address:</Text>
        <Text style={[styles.adress2, styles.addressTypo]}>Adress 2:</Text>
        <Text style={[styles.postalzipCode, styles.addressTypo]}>
          Postal/Zip Code:
        </Text>
        <Pressable
          style={[styles.component3, styles.componentLayout]}
          onPress={() => navigation.navigate("Map1")}
        >
          <Image
            style={styles.iconLayout}
            contentFit="cover"
            source={require("../assets/component-3.png")}
          />
        </Pressable>
        <Pressable
          style={[styles.component4, styles.componentLayout]}
          onPress={() => navigation.navigate("Map1")}
        >
          <Image
            style={styles.iconLayout}
            contentFit="cover"
            source={require("../assets/component-3.png")}
          />
        </Pressable>
        <RectangleComponent
          buttonText="Back"
          rectangleViewTop={752}
          rectangleViewLeft={253}
          rectangleViewWidth={101}
          rectangleViewHeight={35}
          logInBackgroundColor="#7c0707"
          propHeight="60.57%"
          propWidth="73.37%"
          propTop="23.14%"
          propLeft="12.87%"
          onRectanglePressablePress={() => navigation.navigate("LoadPage")}
        />
        <RectangleComponent
          buttonText={`Save
`}
          rectangleViewTop={537}
          rectangleViewLeft={117}
          rectangleViewWidth={124}
          rectangleViewHeight={43}
          logInBackgroundColor="rgba(7, 124, 61, 0.7)"
          propHeight="60.47%"
          propWidth="73.39%"
          propTop="23.26%"
          propLeft="12.9%"
          onRectanglePressablePress={() => navigation.navigate("MainScreen")}
        />
      </ImageBackground>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    height: "100%",
    width: "100%",
  },
  personalLayout: {
    height: 57,
    width: 301,
    backgroundColor: Color.colorGainsboro_100,
    borderRadius: Border.br_112xl,
    left: 29,
    position: "absolute",
  },
  addressTypo: {
    height: 26,
    width: 263,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.icebergRegular,
    fontSize: FontSize.size_3xl,
    left: 48,
    position: "absolute",
  },
  componentLayout: {
    height: 32,
    width: 25,
    left: 291,
    position: "absolute",
  },
  personalInfoChild: {
    top: 746,
    left: 0,
    backgroundColor: Color.colorDarkslateblue_200,
    width: 360,
    height: 54,
    position: "absolute",
  },
  personalInfoItem: {
    top: 125,
  },
  personalInfoInner: {
    top: 228,
  },
  rectangleView: {
    top: 331,
  },
  personalInfoChild1: {
    top: 434,
  },
  firstAndLast: {
    top: 99,
  },
  address: {
    top: 202,
  },
  adress2: {
    top: 305,
  },
  postalzipCode: {
    top: 408,
  },
  component3: {
    top: 240,
  },
  component4: {
    top: 343,
  },
  icon: {
    flex: 1,
    overflow: "hidden",
    backgroundColor: "transparent",
  },
  personalInfo: {
    height: 800,
    width: "100%",
  },
});

export default PersonalInfo;
