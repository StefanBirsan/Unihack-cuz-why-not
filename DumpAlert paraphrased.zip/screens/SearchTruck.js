import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import Property1OnClick from "../components/Property1OnClick";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const SearchTruck = () => {
  return (
    <LinearGradient
      style={styles.searchTruck}
      locations={[0, 0.44, 0.82]}
      colors={["#61bdc9", "#9bbea4", "#3c7b44"]}
    >
      <View style={[styles.searchTruckChild, styles.searchPosition]} />
      <Image
        style={[styles.searchTruckItem, styles.searchPosition]}
        contentFit="cover"
        source={require("../assets/rectangle-18.png")}
      />
      <View style={styles.searchTruckInner} />
      <View style={styles.rectangleView} />
      <Text style={styles.searchForClosest}>
        Search for Closest Truck on the map
      </Text>
      <Property1OnClick
        propTop={254}
        propLeft={31}
        propBackgroundColor="rgba(217, 217, 217, 0.07)"
        propColor="rgba(0, 0, 0, 0.1)"
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  searchPosition: {
    width: 360,
    left: 0,
    position: "absolute",
  },
  searchTruckChild: {
    top: 746,
    backgroundColor: "rgba(22, 14, 14, 0.69)",
    height: 54,
  },
  searchTruckItem: {
    top: 158,
    borderRadius: 211,
    height: 386,
  },
  searchTruckInner: {
    top: 569,
    left: 40,
    borderRadius: Border.br_34xl,
    width: 272,
    height: 83,
    position: "absolute",
  },
  rectangleView: {
    top: 58,
    left: 36,
    borderRadius: 41,
    backgroundColor: Color.colorGainsboro_100,
    width: 299,
    height: 75,
    position: "absolute",
  },
  searchForClosest: {
    top: 67,
    left: 45,
    fontSize: FontSize.size_7xl,
    fontFamily: FontFamily.icebergRegular,
    color: Color.colorBlack,
    textAlign: "center",
    width: 279,
    height: 46,
    position: "absolute",
  },
  searchTruck: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    backgroundColor: "transparent",
  },
});

export default SearchTruck;
