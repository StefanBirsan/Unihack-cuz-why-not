import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import RectangleComponent from "../components/RectangleComponent";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const TOS = () => {
  const navigation = useNavigation();

  return (
    <LinearGradient
      style={styles.tos}
      locations={[0, 1]}
      colors={["#414141", "#3c7b44"]}
    >
      <View
        style={[styles.termsOfServiceForDumpAlerWrapper, styles.termsLayout]}
      >
        <Text
          style={[styles.termsOfService, styles.tosItemPosition]}
        >{`Terms of Service for Dump Alert
Last Updated: 18/11/2023
1. Acceptance of Terms
By using the Dump Alert mobile application (the "App"), you agree to comply with and be bound by these terms of service ("Terms"). If you do not agree to these Terms, please do not use the App.
2. Use of the App
a. Eligibility: You must be at least 18 years old to use the App. By using the App, you represent and warrant that you are at least 18 years old.
b. Registration: To access certain features of the App, you may be required to register for an account. You agree to provide accurate, current, and complete information during the registration process and to update such information to keep it accurate, current, and complete.
c. User Conduct: You agree not to use the App for any unlawful or prohibited purpose. You also agree to comply with all applicable laws and regulations.
3. Garbage Collection Services
a. Scheduling: Users can schedule garbage collection services through the App. The schedule may be subject to availability and geographic limitations.
b. Payment: Users agree to pay the fees associated with the requested garbage collection services. Payment details and processing are handled securely through the App.
4. User Content
a. Responsibility: Users are solely responsible for the content they submit through the App, including but not limited to scheduling requests and communication with service providers.
b. Rights: By submitting content through the App, you grant TheHungryDevs a non-exclusive, royalty-free, worldwide, perpetual, and irrevocable right to use, reproduce, modify, adapt, publish, translate, distribute, and display such content.
5. Privacy
a. Data Collection: TheHungryDevs collects and processes user data in accordance with its Privacy Policy, which can be found below.
b. Security: TheHungryDevs implements reasonable security measures to protect user data; however, no method of transmission over the internet is 100% secure.
6. Termination
TheHungryDevs reserves the right to suspend or terminate your access to the App at any time for any reason, including violation of these Terms.
7. Changes to Terms
TheHungryDevs reserves the right to update or modify these Terms at any time without prior notice. The date of the latest revision will be indicated at the top of these Terms.
8. Contact Information
If you have any questions about these Terms, please contact us at contact@hungrydevs.com .`}</Text>
      </View>
      <View style={styles.tosChild} />
      <RectangleComponent
        buttonText={`Privacy Policy
`}
        rectangleViewTop={1546}
        rectangleViewLeft={96}
        rectangleViewWidth={137}
        rectangleViewHeight={81}
        logInBackgroundColor="rgba(124, 7, 7, 0.7)"
        propHeight="60.49%"
        propWidth="73.36%"
        propTop="23.21%"
        propLeft="12.92%"
        onRectanglePressablePress={() => navigation.navigate("PrivacyPolicy")}
      />
      <View style={[styles.tosItem, styles.tosItemPosition]} />
      <RectangleComponent
        buttonText="Back"
        rectangleViewTop={9}
        rectangleViewLeft={259}
        rectangleViewWidth={101}
        rectangleViewHeight={35}
        logInBackgroundColor="rgba(124, 7, 7, 0.7)"
        propHeight="60.57%"
        propWidth="73.37%"
        propTop="23.14%"
        propLeft="12.87%"
        onRectanglePressablePress={() => navigation.navigate("LoadPage")}
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  termsLayout: {
    height: 494,
    width: 298,
  },
  tosItemPosition: {
    top: 0,
    position: "absolute",
  },
  termsOfService: {
    left: -6,
    fontSize: FontSize.size_3xl,
    fontFamily: FontFamily.timesNewRoman,
    color: Color.colorWhite,
    textAlign: "left",
    height: 494,
    width: 298,
  },
  termsOfServiceForDumpAlerWrapper: {
    top: 67,
    left: 31,
    position: "absolute",
  },
  tosChild: {
    top: 2224,
    left: 96,
    width: 137,
    height: 81,
    position: "absolute",
  },
  tosItem: {
    left: 0,
    backgroundColor: Color.colorDarkslateblue_100,
    width: 360,
    height: 54,
  },
  tos: {
    flex: 1,
    width: "100%",
    height: 800,
    backgroundColor: "transparent",
  },
});

export default TOS;
